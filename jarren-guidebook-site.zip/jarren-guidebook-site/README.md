# Jarren Guidebook Site

## Run locally
1. npm install
2. npm run dev

## Deploy on Vercel
1. Create a new GitHub repo and upload these files
2. Go to vercel.com
3. Import the repo
4. Click Deploy

## Important next steps
- Replace placeholder buttons with your Stripe, Gumroad, Payhip, or Stan links
- Replace sample preview text with real guidebook preview pages
- Add your real blog post URLs
