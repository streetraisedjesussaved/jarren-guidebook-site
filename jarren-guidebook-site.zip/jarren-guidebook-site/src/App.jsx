import React, { useMemo, useState } from "react";

function BaseIcon({ className = "h-5 w-5", children }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      {children}
    </svg>
  );
}

const ShoppingBagIcon = ({ className }) => <BaseIcon className={className}><path d="M6 8h12l-1 11H7L6 8Z" /><path d="M9 8a3 3 0 0 1 6 0" /></BaseIcon>;
const BookOpenIcon = ({ className }) => <BaseIcon className={className}><path d="M12 7c-2.2-1.3-4.4-2-7-2v13c2.6 0 4.8.7 7 2" /><path d="M12 7c2.2-1.3 4.4-2 7-2v13c-2.6 0-4.8.7-7 2" /><path d="M12 7v13" /></BaseIcon>;
const ArrowRightIcon = ({ className }) => <BaseIcon className={className}><path d="M5 12h14" /><path d="m13 5 7 7-7 7" /></BaseIcon>;
const PlayCircleIcon = ({ className }) => <BaseIcon className={className}><circle cx="12" cy="12" r="9" /><path d="m10 9 5 3-5 3V9Z" fill="currentColor" stroke="none" /></BaseIcon>;
const CheckCircleIcon = ({ className }) => <BaseIcon className={className}><circle cx="12" cy="12" r="9" /><path d="m8.5 12 2.3 2.3 4.7-4.8" /></BaseIcon>;
const StarIcon = ({ className }) => <BaseIcon className={className}><path d="m12 3 2.7 5.4 6 .9-4.3 4.2 1 6-5.4-2.8-5.4 2.8 1-6L3.3 9.3l6-.9L12 3Z" /></BaseIcon>;
const LockIcon = ({ className }) => <BaseIcon className={className}><rect x="5" y="11" width="14" height="10" rx="2" /><path d="M8 11V8a4 4 0 1 1 8 0v3" /></BaseIcon>;
const FileTextIcon = ({ className }) => <BaseIcon className={className}><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Z" /><path d="M14 3v5h5" /><path d="M9 13h6" /><path d="M9 17h6" /><path d="M9 9h2" /></BaseIcon>;
const HeartHandshakeIcon = ({ className }) => <BaseIcon className={className}><path d="M8.5 12.5 6.8 14a2 2 0 0 1-2.8 0 2 2 0 0 1 0-2.8l3.4-3.4a3 3 0 0 1 4.2 0l.4.4" /><path d="m15.5 11.5 1.7-1.5a2 2 0 0 1 2.8 0 2 2 0 0 1 0 2.8l-3.4 3.4a3 3 0 0 1-4.2 0l-.4-.4" /><path d="m9.5 14.5 5-5" /><path d="m11 16 5-5" /></BaseIcon>;
const CreditCardIcon = ({ className }) => <BaseIcon className={className}><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 10h18" /><path d="M7 15h3" /></BaseIcon>;
const ChevronLeftIcon = ({ className }) => <BaseIcon className={className}><path d="m15 18-6-6 6-6" /></BaseIcon>;
const ChevronRightIcon = ({ className }) => <BaseIcon className={className}><path d="m9 18 6-6-6-6" /></BaseIcon>;

export default function App() {
  const guidebooks = useMemo(() => ([
    {
      slug: "family-recovery-guidebook",
      title: "The Family Recovery Guidebook",
      subtitle: "From crisis to healing — a practical map for families rebuilding in real life.",
      price: "$19",
      badge: "Best Seller",
      audience: "For parents rebuilding stability, structure, and safety",
      includes: [
        "Crisis planning worksheets",
        "Repair-based parenting tools",
        "Emotional regulation practices",
        "Family stability check-ins",
      ],
      previewPages: [
        { heading: "Welcome", body: "This guidebook was built for the days when survival feels louder than hope. Inside are grounded tools, scripts, and systems to help families return, repair, and restart." },
        { heading: "What This Book Helps You Do", body: "Create calmer routines, respond instead of react, plan for hard days before they happen, and build a home culture that feels safer, steadier, and more honest." },
        { heading: "Inside the Toolkit", body: "You will find checklists, reflection prompts, family meeting frameworks, repair scripts, and practical action pages designed to be used in real life — not just admired." },
      ],
    },
    {
      slug: "family-blueprint",
      title: "The Family Blueprint",
      subtitle: "Structure, rhythm, and systems that make safety feel real.",
      price: "$15",
      badge: "Most Structured",
      audience: "For families who need routines that actually hold",
      includes: [
        "Home rhythm planning",
        "Weekly family reset pages",
        "Connection-first structure",
        "Household system builders",
      ],
      previewPages: [
        { heading: "Your Home Needs a System", body: "The goal is not perfection. The goal is a home that can keep holding you when life gets noisy, tired, emotional, or stretched thin." },
        { heading: "Structure That Feels Human", body: "This blueprint helps you build routines with softness — a system that supports real people, real moods, and real family life." },
        { heading: "What You’ll Build", body: "Morning anchors, evening resets, meeting rhythms, expectation clarity, and family agreements that reduce chaos without killing connection." },
      ],
    },
    {
      slug: "financial-recovery-workbook",
      title: "Financial Recovery Workbook",
      subtitle: "Money tools for rebuilding without shame, pressure, or fake perfection.",
      price: "$12",
      badge: "Most Practical",
      audience: "For people rebuilding their finances one clear step at a time",
      includes: [
        "Recovery budget worksheets",
        "Emergency cushion planner",
        "Stability-first spending tools",
        "Financial stress reflection pages",
      ],
      previewPages: [
        { heading: "Money Is Emotional Too", body: "This workbook treats money like part of recovery, not a moral test. The goal is safety, clarity, and small wins that stack over time." },
        { heading: "Start With What Is True", body: "No shame math. No fantasy budgets. Just a clean place to name what is happening, what is urgent, and what can be rebuilt next." },
        { heading: "What’s Included", body: "Simple budget pages, debt focus tools, survival spending planning, emergency savings goals, and practical reset worksheets you can actually use." },
      ],
    },
  ]), []);

  const featuredPosts = [
    { title: "Starting Over Without Starting From Nothing", category: "Rebuilding", excerpt: "You still have wisdom, pattern recognition, survival skills, and strength — even if life looks broken right now." },
    { title: "Structure Is Safety, Not Punishment", category: "Family Systems", excerpt: "What stable routines really do for overwhelmed homes, overstimulated kids, and tired adults." },
    { title: "Money Stress Is Nervous System Stress", category: "Financial Recovery", excerpt: "Why financial tools have to work with your real life, not against it." },
  ];

  const tiktokSteps = [
    { title: "TikTok Hook", text: "Lead with the hard truth, the blunt line, or the real-life pain point that makes people stop scrolling." },
    { title: "Blog Post", text: "Send them to a deeper post that gives context, story, and one practical shift they can use today." },
    { title: "Preview Pages", text: "Let them open the guidebook and feel the value before asking for the sale." },
    { title: "Checkout", text: "Keep the buying step simple, clear, emotional, and low-friction so the reader can say yes fast." },
  ];

  const [selectedBook, setSelectedBook] = useState(0);
  const [currentPreviewPage, setCurrentPreviewPage] = useState(0);
  const book = guidebooks[selectedBook];
  const preview = book.previewPages[currentPreviewPage];

  const jump = (id) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900">
      <header className="sticky top-0 z-30 border-b border-stone-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.35em] text-stone-500">Jarren Writes</p>
            <h1 className="text-2xl font-black tracking-tight">Guidebooks, stories, and tools that move people from pain to action ✨</h1>
          </div>
          <div className="hidden items-center gap-6 md:flex">
            <a href="#landing" className="text-sm font-semibold hover:text-stone-600">Landing Page</a>
            <a href="#preview" className="text-sm font-semibold hover:text-stone-600">Preview Reader</a>
            <a href="#checkout" className="text-sm font-semibold hover:text-stone-600">Checkout</a>
            <a href="#system" className="text-sm font-semibold hover:text-stone-600">TikTok Funnel</a>
          </div>
        </div>
      </header>

      <main>
        <section id="landing" className="border-b border-stone-200 bg-white">
          <div className="mx-auto grid max-w-7xl gap-10 px-6 py-14 md:grid-cols-[1.1fr_0.9fr] md:py-20">
            <div className="flex flex-col justify-center">
              <div className="mb-5 inline-flex w-fit items-center gap-2 rounded-full bg-rose-100 px-4 py-2 text-xs font-bold uppercase tracking-[0.2em] text-rose-700">
                <HeartHandshakeIcon className="h-4 w-4" /> Built for healing, structure, and real-life rebuilding
              </div>
              <h2 className="max-w-3xl text-5xl font-black leading-[1.02] tracking-tight md:text-7xl">A high-converting guidebook shop wrapped inside a story-first brand.</h2>
              <p className="mt-6 max-w-2xl text-lg leading-8 text-stone-600">This page is built to do four things beautifully: pull people in with your message, let them preview your guidebooks like a real reader, guide them into checkout, and turn short-form content into sales without losing heart.</p>
              <div className="mt-8 flex flex-wrap gap-3">
                <a href="#guidebooks" className="rounded-2xl bg-stone-900 px-6 py-3 text-sm font-bold text-white shadow-sm transition hover:-translate-y-0.5">Explore guidebooks</a>
                <a href="#system" className="rounded-2xl border border-stone-300 bg-white px-6 py-3 text-sm font-bold text-stone-900 transition hover:bg-stone-100">See the sales system</a>
              </div>
            </div>

            <div className="rounded-[2rem] bg-gradient-to-br from-stone-900 via-stone-800 to-rose-950 p-8 text-white shadow-xl">
              <p className="text-xs font-semibold uppercase tracking-[0.3em] text-stone-300">High-converting guidebook landing page</p>
              <h3 className="mt-4 text-3xl font-black leading-tight">Tools people can trust because they can feel the care before they buy.</h3>
              <div className="mt-8 space-y-4">
                {["Clear value stack for each guidebook","Reader-style preview experience","Testimonial-ready layout blocks","Fast CTA flow from content to checkout"].map((item) => (
                  <div key={item} className="flex items-start gap-3 rounded-2xl bg-white/10 px-4 py-4 backdrop-blur-sm">
                    <CheckCircleIcon className="mt-0.5 h-5 w-5 shrink-0" />
                    <p className="text-sm leading-6 text-stone-100">{item}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section id="guidebooks" className="mx-auto max-w-7xl px-6 py-14 md:py-20">
          <div className="mb-8 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="text-sm font-bold uppercase tracking-[0.25em] text-stone-500">Guidebook storefront</p>
              <h3 className="mt-2 text-4xl font-black tracking-tight">Choose the tool, then step inside it 📚</h3>
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            {guidebooks.map((item, index) => {
              const isSelected = selectedBook === index;
              return (
                <div key={item.slug} className={`rounded-[2rem] p-6 shadow-sm ring-1 transition ${isSelected ? "bg-stone-900 text-white ring-stone-900" : "bg-white text-stone-900 ring-stone-200"}`}>
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className={`text-xs font-bold uppercase tracking-[0.22em] ${isSelected ? "text-stone-300" : "text-stone-500"}`}>{item.badge}</p>
                      <h4 className="mt-2 text-2xl font-black leading-tight">{item.title}</h4>
                    </div>
                    <div className={`rounded-full px-3 py-1 text-sm font-black ${isSelected ? "bg-white text-stone-900" : "bg-rose-100 text-rose-700"}`}>{item.price}</div>
                  </div>
                  <p className={`mt-4 text-sm leading-7 ${isSelected ? "text-stone-200" : "text-stone-600"}`}>{item.subtitle}</p>
                  <p className={`mt-4 text-sm font-semibold ${isSelected ? "text-stone-100" : "text-stone-800"}`}>{item.audience}</p>
                  <div className="mt-5 space-y-3">
                    {item.includes.map((bullet) => (
                      <div key={bullet} className="flex items-start gap-3">
                        <StarIcon className={`mt-0.5 h-4 w-4 shrink-0 ${isSelected ? "text-rose-300" : "text-rose-500"}`} />
                        <p className={`text-sm ${isSelected ? "text-stone-200" : "text-stone-600"}`}>{bullet}</p>
                      </div>
                    ))}
                  </div>
                  <div className="mt-8 grid gap-3">
                    <button type="button" onClick={() => { setSelectedBook(index); setCurrentPreviewPage(0); jump("preview"); }} className={`rounded-2xl px-4 py-3 text-sm font-bold transition ${isSelected ? "bg-white text-stone-900" : "border border-stone-300 bg-white text-stone-900"}`}>Preview this guidebook</button>
                    <button type="button" onClick={() => { setSelectedBook(index); setCurrentPreviewPage(0); jump("checkout"); }} className={`rounded-2xl px-4 py-3 text-sm font-bold transition ${isSelected ? "bg-rose-400 text-stone-950" : "bg-stone-900 text-white"}`}>Buy full version</button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        <section id="preview" className="border-y border-stone-200 bg-stone-100/70">
          <div className="mx-auto grid max-w-7xl gap-8 px-6 py-14 md:grid-cols-[0.85fr_1.15fr] md:py-20">
            <div className="rounded-[2rem] bg-white p-8 shadow-sm ring-1 ring-stone-200">
              <p className="text-sm font-bold uppercase tracking-[0.24em] text-stone-500">Full preview page design</p>
              <h3 className="mt-3 text-4xl font-black tracking-tight">A real book-reader feel 👀</h3>
              <div className="mt-8 rounded-3xl bg-rose-50 p-5 ring-1 ring-rose-100">
                <p className="text-xs font-bold uppercase tracking-[0.22em] text-rose-700">Now previewing</p>
                <h4 className="mt-2 text-2xl font-black text-stone-900">{book.title}</h4>
                <p className="mt-3 text-sm leading-7 text-stone-600">{book.subtitle}</p>
              </div>
              <div className="mt-6 space-y-3">
                {book.previewPages.map((page, index) => (
                  <button key={page.heading} type="button" onClick={() => setCurrentPreviewPage(index)} className={`flex w-full items-center justify-between rounded-2xl px-4 py-4 text-left transition ${currentPreviewPage === index ? "bg-stone-900 text-white" : "bg-stone-50 text-stone-900 ring-1 ring-stone-200 hover:bg-white"}`}>
                    <span>
                      <span className={`block text-xs font-bold uppercase tracking-[0.18em] ${currentPreviewPage === index ? "text-stone-300" : "text-stone-500"}`}>Sample page {index + 1}</span>
                      <span className="mt-1 block text-sm font-bold">{page.heading}</span>
                    </span>
                    <BookOpenIcon className="h-4 w-4" />
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-[2rem] bg-stone-900 p-4 shadow-xl md:p-8">
              <div className="mx-auto flex max-w-3xl items-center justify-between rounded-t-[1.5rem] border-b border-white/10 bg-stone-950/60 px-5 py-4 text-white">
                <div className="flex items-center gap-3">
                  <div className="rounded-xl bg-white/10 p-2"><FileTextIcon className="h-5 w-5" /></div>
                  <div><p className="text-sm font-bold">Preview Reader</p><p className="text-xs text-stone-400">Sample pages only</p></div>
                </div>
                <div className="rounded-full bg-white/10 px-3 py-1 text-xs font-bold uppercase tracking-[0.2em] text-stone-300">{book.price}</div>
              </div>

              <div className="mx-auto max-w-3xl rounded-b-[1.5rem] bg-[#f8f3ea] px-6 py-8 md:px-10 md:py-12">
                <div className="rounded-[1.5rem] bg-white p-8 shadow-lg ring-1 ring-stone-200 md:p-12">
                  <div className="flex items-center justify-between border-b border-stone-200 pb-4">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-[0.22em] text-stone-500">{book.title}</p>
                      <h4 className="mt-2 text-3xl font-black leading-tight text-stone-900">{preview.heading}</h4>
                    </div>
                    <div className="rounded-full bg-stone-100 px-3 py-1 text-xs font-bold uppercase tracking-[0.2em] text-stone-600">Page {currentPreviewPage + 1}/{book.previewPages.length}</div>
                  </div>

                  <div className="min-h-[290px] pt-8">
                    <p className="text-lg leading-9 text-stone-700">{preview.body}</p>
                    <div className="mt-10 rounded-3xl border border-stone-200 bg-stone-50 p-6">
                      <p className="text-xs font-bold uppercase tracking-[0.22em] text-stone-500">Reader note</p>
                      <p className="mt-3 text-base leading-8 text-stone-600">The full version includes deeper guidance, worksheets, action pages, and the complete system — this sample is here to let readers feel the tone, quality, and usefulness before purchase.</p>
                    </div>
                  </div>

                  <div className="mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-stone-200 pt-6">
                    <div className="flex gap-3">
                      <button type="button" onClick={() => setCurrentPreviewPage((prev) => Math.max(prev - 1, 0))} className="inline-flex items-center gap-2 rounded-2xl border border-stone-300 bg-white px-4 py-3 text-sm font-bold text-stone-900"><ChevronLeftIcon className="h-4 w-4" /> Prev</button>
                      <button type="button" onClick={() => setCurrentPreviewPage((prev) => Math.min(prev + 1, book.previewPages.length - 1))} className="inline-flex items-center gap-2 rounded-2xl border border-stone-300 bg-white px-4 py-3 text-sm font-bold text-stone-900">Next <ChevronRightIcon className="h-4 w-4" /></button>
                    </div>
                    <button type="button" onClick={() => jump("checkout")} className="inline-flex items-center gap-2 rounded-2xl bg-stone-900 px-5 py-3 text-sm font-bold text-white"><LockIcon className="h-4 w-4" /> Buy full access</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="checkout" className="mx-auto max-w-7xl px-6 py-14 md:py-20">
          <div className="mb-8">
            <p className="text-sm font-bold uppercase tracking-[0.25em] text-stone-500">Checkout page layout</p>
            <h3 className="mt-2 text-4xl font-black tracking-tight">A warm, clean checkout that closes the sale 💰</h3>
          </div>

          <div className="grid gap-6 md:grid-cols-[1fr_0.78fr]">
            <div className="rounded-[2rem] bg-white p-8 shadow-sm ring-1 ring-stone-200">
              <h4 className="text-2xl font-black">Complete your order</h4>
              <div className="mt-8 grid gap-5 md:grid-cols-2">
                <div><label className="text-sm font-bold text-stone-700">First name</label><input className="mt-2 w-full rounded-2xl border border-stone-300 px-4 py-3 outline-none" placeholder="Jarren" /></div>
                <div><label className="text-sm font-bold text-stone-700">Last name</label><input className="mt-2 w-full rounded-2xl border border-stone-300 px-4 py-3 outline-none" placeholder="Breeling" /></div>
                <div className="md:col-span-2"><label className="text-sm font-bold text-stone-700">Email address</label><input className="mt-2 w-full rounded-2xl border border-stone-300 px-4 py-3 outline-none" placeholder="you@example.com" /></div>
              </div>

              <div className="mt-8 rounded-3xl border border-stone-200 bg-stone-50 p-5">
                <div className="flex items-center gap-3"><CreditCardIcon className="h-5 w-5 text-stone-700" /><p className="text-sm font-black">Payment details</p></div>
                <div className="mt-5 space-y-4">
                  <input className="w-full rounded-2xl border border-stone-300 px-4 py-3 outline-none" placeholder="Card number" />
                  <div className="grid gap-4 md:grid-cols-2">
                    <input className="w-full rounded-2xl border border-stone-300 px-4 py-3 outline-none" placeholder="MM / YY" />
                    <input className="w-full rounded-2xl border border-stone-300 px-4 py-3 outline-none" placeholder="CVC" />
                  </div>
                </div>
              </div>

              <div className="mt-8 flex flex-wrap gap-3">
                <button type="button" className="inline-flex items-center gap-2 rounded-2xl bg-stone-900 px-6 py-3 text-sm font-bold text-white"><ShoppingBagIcon className="h-4 w-4" /> Buy now</button>
                <button type="button" className="rounded-2xl border border-stone-300 bg-white px-6 py-3 text-sm font-bold text-stone-900">Pay with express checkout</button>
              </div>
            </div>

            <div className="space-y-6">
              <div className="rounded-[2rem] bg-stone-900 p-8 text-white shadow-sm">
                <p className="text-xs font-bold uppercase tracking-[0.22em] text-stone-300">Order summary</p>
                <h4 className="mt-3 text-2xl font-black">{book.title}</h4>
                <p className="mt-3 text-sm leading-7 text-stone-300">{book.subtitle}</p>
                <div className="mt-6 space-y-3">
                  {book.includes.map((item) => (
                    <div key={item} className="flex items-start gap-3 rounded-2xl bg-white/10 px-4 py-4">
                      <CheckCircleIcon className="mt-0.5 h-4 w-4 shrink-0 text-rose-300" />
                      <p className="text-sm text-stone-100">{item}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-8 flex items-center justify-between border-t border-white/10 pt-6">
                  <span className="text-sm text-stone-300">Total</span>
                  <span className="text-3xl font-black">{book.price}</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="border-y border-stone-200 bg-white">
          <div className="mx-auto max-w-7xl px-6 py-14 md:py-20">
            <div className="mb-8 max-w-3xl">
              <p className="text-sm font-bold uppercase tracking-[0.25em] text-stone-500">Blog to product bridge</p>
              <h3 className="mt-2 text-4xl font-black tracking-tight">Featured posts that warm readers up before the buy</h3>
            </div>
            <div className="grid gap-6 md:grid-cols-3">
              {featuredPosts.map((post) => (
                <article key={post.title} className="rounded-[2rem] bg-stone-50 p-6 ring-1 ring-stone-200 transition hover:-translate-y-1">
                  <p className="text-xs font-bold uppercase tracking-[0.22em] text-stone-500">{post.category}</p>
                  <h4 className="mt-3 text-2xl font-black leading-tight">{post.title}</h4>
                  <p className="mt-4 text-sm leading-7 text-stone-600">{post.excerpt}</p>
                  <button type="button" className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-stone-900">Read post <ArrowRightIcon className="h-4 w-4" /></button>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="system" className="mx-auto max-w-7xl px-6 py-14 md:py-20">
          <div className="grid gap-8 md:grid-cols-[0.9fr_1.1fr]">
            <div>
              <p className="text-sm font-bold uppercase tracking-[0.25em] text-stone-500">TikTok → blog → buy system</p>
              <h3 className="mt-2 text-4xl font-black tracking-tight">This is the traffic and conversion engine 📱</h3>
              <p className="mt-5 text-base leading-8 text-stone-600">This system is built so your short videos are not random content. Each piece has a job: stop the scroll, deepen trust, preview the value, and move the right people into the sale.</p>
              <div className="mt-8 rounded-[2rem] bg-stone-900 p-6 text-white">
                <div className="flex items-center gap-3"><PlayCircleIcon className="h-5 w-5 text-rose-300" /><p className="text-sm font-black">Suggested TikTok CTA</p></div>
                <p className="mt-4 text-lg font-bold leading-8">“If this hit home, go read the full post and open the preview pages — the full guidebook is there when you’re ready.”</p>
              </div>
            </div>

            <div className="grid gap-5">
              {tiktokSteps.map((step, index) => (
                <div key={step.title} className="rounded-[2rem] bg-white p-6 shadow-sm ring-1 ring-stone-200">
                  <div className="flex items-start gap-4">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-rose-100 text-lg font-black text-rose-700">{index + 1}</div>
                    <div>
                      <h4 className="text-xl font-black">{step.title}</h4>
                      <p className="mt-2 text-sm leading-7 text-stone-600">{step.text}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
